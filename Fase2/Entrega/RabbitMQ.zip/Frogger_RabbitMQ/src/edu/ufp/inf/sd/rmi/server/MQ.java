package edu.ufp.inf.sd.rmi.server;

import com.rabbitmq.client.*;
import edu.ufp.inf.sd.rmi.client.Coordenadas;
import edu.ufp.inf.sd.rmi.client.frogger.Main;
import edu.ufp.inf.sd.rmi.server.State.State;
import edu.ufp.inf.sd.rmi.server.State.StateMovimento;
import edu.ufp.inf.sd.rmi.server.State.StateTransito;
import edu.ufp.inf.sd.rmi.util.RabbitUtils;

import java.io.IOException;
import java.rmi.RemoteException;
import java.util.Objects;
import java.util.concurrent.TimeoutException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class MQ {
    static String HOST = "localhost";
    static int PORT = 5672;
    static String EXCHANGE_CLIENT = "ExchangeClient";
    static String QUEUE_SERVER = "Queue_Server";


    public static void initServer() {
        try{
            Connection connection=RabbitUtils.newConnection2Server(HOST, PORT, "guest", "guest");
            Channel channel=RabbitUtils.createChannel2Server(connection);
            channel.queueDeclare(QUEUE_SERVER, false, false, false, null);
            System.out.println(" [*] Waiting for messages. To exit press CTRL+C");
            boolean run = true;
            DeliverCallback deliverCallback=(consumerTag, delivery) -> {
                String message=new String(delivery.getBody(), "UTF-8");
                System.out.println(" [x] Server Received '" + message + "'");
                State gameState = createState(message);
                sendToClients(gameState);
                while (!run){
                    try {
                        long sleepMillis = 2000;
                        Thread.sleep(sleepMillis);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            };
            channel.basicConsume(QUEUE_SERVER, true, deliverCallback, consumerTag -> {
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void sendToServer(State state) {
        try (Connection connection= RabbitUtils.newConnection2Server(HOST, PORT, "guest", "guest");
             Channel channel=RabbitUtils.createChannel2Server(connection)) {
            channel.queueDeclare(QUEUE_SERVER, false, false, false, null);
            String message=state.toString();
            channel.basicPublish("", QUEUE_SERVER, null, message.getBytes("UTF-8"));
            System.out.println(" [x] Sent to server '" + message + "'");
        } catch (IOException | TimeoutException e) {
            Logger.getLogger(RabbitUtils.class.getName()).log(Level.INFO, e.toString());
        }
    }

    public static void initClient() {
        Runnable runnable = () -> {
            try {
                Connection connection = RabbitUtils.newConnection2Server(HOST, PORT, "guest", "guest");
                Channel channel = RabbitUtils.createChannel2Server(connection);
                channel.exchangeDeclare(EXCHANGE_CLIENT, BuiltinExchangeType.FANOUT);
                String queueName = channel.queueDeclare().getQueue();
                String routingKey = "";
                channel.queueBind(queueName, EXCHANGE_CLIENT, routingKey);
                Logger.getAnonymousLogger().log(Level.INFO, Thread.currentThread().getName() + ": Will create Deliver Callback...");
                System.out.println("[*] Waiting for messages. To exit press CTRL+C");
                DeliverCallback deliverCallback = (consumerTag, delivery) -> {
                    String message = new String(delivery.getBody(), "UTF-8");
                    //System.out.println(" [x] Consumer Tag [" + consumerTag + "] - Received '" + message + "'");
                    System.out.println(" [x] Client (" + consumerTag + ") received '" + message + "'");
                    State gameState = createState(message);
                    DB.getInstance().game.setGameState(gameState);
                };
                CancelCallback cancelCallback = (consumerTag) -> {
                    System.out.println("[x] Consumer Tag [" + consumerTag + "] - Cancel Callback invoked!");
                };
                channel.basicConsume(queueName, true, deliverCallback, cancelCallback);
            } catch (Exception e) {
                e.printStackTrace();
            }
        };
        Thread thread = new Thread(runnable);
        thread.start();
    }

    public static void sendToClients(State state) {
        try {
            Connection connection= RabbitUtils.newConnection2Server(HOST, PORT, "guest", "guest");
            Channel channel=RabbitUtils.createChannel2Server(connection);
            channel.exchangeDeclare(EXCHANGE_CLIENT, BuiltinExchangeType.FANOUT);
            String routingKey = "";
            channel.basicPublish(EXCHANGE_CLIENT, routingKey, null, state.toString().getBytes("UTF-8"));
            System.out.println(" [x] Sent to Clients: " + state.toString());
        } catch (IOException | TimeoutException e) {
            Logger.getLogger(Main.class.getName()).log(Level.INFO, e.toString());
        }
    }

    public static State createState(String message) throws RemoteException {
        String[] part = message.split(",");
        if (Objects.equals(part[0], "State")) {
            return newState(Integer.parseInt(part[1]), Integer.parseInt(part[2]), Integer.parseInt(part[3]));
        }
        if (Objects.equals(part[0], "StateMovimento")) {
            return newStateMovimento(Integer.parseInt(part[1]), Integer.parseInt(part[2]), Integer.parseInt(part[3]), Integer.parseInt(part[4]), Integer.parseInt(part[5]));
        }
        if (Objects.equals(part[0], "StateTransito")) {
            int score = Integer.parseInt(part[1]);
            int timer = Integer.parseInt(part[2]);
            int level = Integer.parseInt(part[3]);
            String type = part[4];
            Coordenadas position = new Coordenadas(Double.parseDouble(part[5]), Double.parseDouble(part[6]));
            Coordenadas velocity = new Coordenadas(Double.parseDouble(part[7]), Double.parseDouble(part[8]));
            String spriteName = part[9];
            long deltaMs = Long.parseLong(part[10]);
            return newStateTransito(score,timer,level,type,position,velocity,spriteName,deltaMs);
        }
        return null;
    }

    public static State newState(int score, int timer, int level) {
        return new State(score, timer, level);
    }

    public static StateMovimento newStateMovimento(int pontuacao, int timer, int level, Integer id, int direction){
        return new StateMovimento(pontuacao, timer, level, id, direction);
    }

    public static StateTransito newStateTransito(int score, int timer, int level, String type, Coordenadas position, Coordenadas velocity, String spriteName, long deltaMs){
        return new StateTransito(score, timer, level, type, position, velocity, spriteName, deltaMs);
    }

}
